

package FlooringMastery.Service;

/**
 *
 * @author Shantoria Taylor  

 */
public class MinimumException extends Exception {
    
    MinimumException(String message) {
        super(message);
    }

    MinimumException(String message, Throwable cause) {
        super(message, cause);
    }

}
