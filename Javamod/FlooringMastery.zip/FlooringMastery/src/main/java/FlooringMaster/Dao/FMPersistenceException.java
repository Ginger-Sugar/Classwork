

package FlooringMaster.Dao;

/**
 *
 * @author Shantoria Taylor 

 */
public class FMPersistenceException extends Exception {
    
    FMPersistenceException(String message) {
        super(message);
    }

    FMPersistenceException(String message, Throwable cause) {
        super(message, cause);
    }

}
